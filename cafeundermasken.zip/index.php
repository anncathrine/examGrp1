<!DOCTYPE html>
<!--- kode af Maj --->
<html lang="da">
<head>
<meta name="Robots" content="index, follow">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Café Under Masken">
<meta http-equiv="author" content="Pernille, Ann Cathrine, Martin, Maj - Gruppe 1">
<title>Café Under Masken</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="css/stylesheet.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


<!---[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/
➥3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/
➥1.4.2/respond.min.js"></script>
<![endif]--->
</head>

<body>
  <!--- JavaScript til bootstrap --->
  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.js"></script>


<!--- Navigation --->
<?php include 'includes/header.php';?>


<!---
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<nav class="navbar navbar-inverse navbar-fixed-top">
  <ul class="nav navbar-nav">
      <li><a href="#events">Events</a></li>
      <li><a href="#barogcafe">Bar & Café</a></li>
      <li><a href="#voreshistorie">Vores historie</a></li>
      <li><a href="#kontaktos">Kontakt</a></li>
    </ul>
</nav>
</div>
--->

<!--- Main --->

<!--- Carousel --->
<center>
    <div class="col-lg-12 col-md-12 col-sm-12- col-xs-12">
    <div id="myCarousel" class="carousel-slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
      </ol>

      <!--- Wrapper for slides --->
      <div class="carousel-inner">
        <div class="item active">
          <img src="images/forsidenn.jpg" alt="Café Under Masken" class="tales" style="width:100%;">
        </div>

        <div class="item">
          <img src="images/slide2.jpg" alt="Café Under Masken" class="tales" style="width:100%;">
        </div>

        <div class="item">
          <img src="images/slide3.jpg" alt="Café Under Masken" class="tales" style="width:100%;">
        </div>
      </div>
  </div>
  </div>
</div>
</center>
<!--- Carousel end --->
<!--- Kode af Maj slut --->

<!--- Kode af Ann Cathrine -->
<!--- Accordion --->
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<div class="panel-group" id="accordion">
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title" id="events">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">
        <center>Events</center></a>
      </h4>
    </div>
<div id="collapse1" class="panel-collapse collapse">
<div class="panel-body">
<p>Hos Café Under Masken ønsker vi at skabe god stemning og
afholde interessante arrangementer for vores gæster. Skal du være med?</p>
<p>Vi afholder ofte arrangementer, hvor vi inviterer musikere med ind i varmen og lader
dem fylde vores hyggelige lokale med gode toner, hvor du selvfølgelig er velkommen!
Kom og brug en aften i vores selskab eller gør den kedelige søndag til en solskinsdag
og deltag i vores faste søndagsarrangement.</p>
<p>Kalenderen giver overblik over hvornår vi afholder events og hvem vi har inviteret med indenfor.</p>
</div>

<p class="Kalender">
<div class="cd-schedule loading">
	<div class="timeline">
		<ul>
			<li><span>12:00</span></li>
			<li><span>12:30</span></li>
			<li><span>13:00</span></li>
			<li><span>13:30</span></li>
			<li><span>14:00</span></li>
			<li><span>14:30</span></li>
			<li><span>15:00</span></li>
			<li><span>15:30</span></li>
			<li><span>16:00</span></li>
			<li><span>16:30</span></li>
			<li><span>17:00</span></li>
			<li><span>17:30</span></li>
			<li><span>18:00</span></li>
			<li><span>18:30</span></li>
			<li><span>19:00</span></li>
			<li><span>19:30</span></li>
			<li><span>20:00</span></li>
			<li><span>20:30</span></li>
			<li><span>21:00</span></li>

		</ul>
	</div> <!-- .timeline -->

  <div class="events">
		<ul>
			<li class="events-group">
				<div class="top-info"><span>Mandag</span></div>

        <ul>
					<li class="single-event" data-start="13:00" data-end="21:30"  data-content="event-yoga-1" data-event="event-3">
						<a href="#0">
							<em class="event-name">Brætspils hygge</em>
						</a>
					</li>
				</ul>
			</li>
    <ul>
			<li class="events-group">
				<div class="top-info"><span>Tirsdag</span></div>

        <ul>
          <li class="single-event" data-start="14:00" data-end="18:00"  data-content="event-rowing-workout" data-event="event-2">
            <a href="#0">
              <em class="event-name">Jazz musik og brætspil</em>
            </a>
          </li>
			</li>
    </ul>

			<li class="events-group">
				<div class="top-info"><span>Onsdag</span></div>

				<ul>
					<li class="single-event" data-start="19:00" data-end="21:30"  data-content="event-rowing-workout" data-event="event-2">
						<a href="#0">
							<em class="event-name">Hey Joe!</em>
						</a>
					</li>
				</ul>
			</li>

			<li class="events-group">
				<div class="top-info"><span>Torsdag</span></div>
        <ul>
					<li class="single-event" data-start="18:00" data-end="21:30" data-content="event-restorative-yoga" data-event="event-4">
						<a href="#0">
							<em class="event-name">Magisk torsdag!</em>
						</a>
					</li>
				</ul>
			</li>

			<li class="events-group">
				<div class="top-info"><span>Fredag</span></div>

				<ul>
					<li class="single-event" data-start="12:00" data-end="15:00"  data-content="event-rowing-workout" data-event="event-2">
						<a href="#0">
							<em class="event-name">Weekend opvarmning</em>
						</a>
					</li>

					<li class="single-event" data-start="20:00" data-end="21:30"  data-content="event-yoga-1" data-event="event-3">
						<a href="#0">
							<em class="event-name">The Dub DJ</em>
						</a>
					</li>
				</ul>
			</li>

      <li class="events-group">
        <div class="top-info"><span>Lørdag</span></div>

       <ul>
          <li class="single-event" data-start="19:00" data-end="21:30"  data-content="event-yoga-1" data-event="event-3">
            <a href="#0">
              <em class="event-name">Lørdags rock</em>
            </a>
          </li>
        </ul>
      </li>

      <li class="events-group">
        <div class="top-info"><span>Søndag</span></div>

        <ul>
          <li class="single-event" data-start="18:00" data-end="21:30"  data-content="event-rowing-workout" data-event="event-2">
            <a href="#0">
              <em class="event-name">Tømmer-slam</em>
            </a>
          </li>
        </ul>
      </li>
	</div>
</div>

  <div class="event-modal">
		<header class="header">
			<div class="content">
				<span class="event-date"></span>
				<h3 class="event-name"></h3>
			</div>

			<div class="header-bg"></div>
		</header>

		<div class="body">
			<div class="event-info"></div>
			<div class="body-bg"></div>
		</div>

		<a href="#0" class="close">Close</a>
	</div>

	<div class="cover-layer"></div>
</div>

 <!-- .cd-schedule -->
<script>
     jQuery(document).ready(function($){
  var transitionEnd = 'webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend';
  var transitionsSupported = ( $('.csstransitions').length > 0 );
  //if browser does not support transitions - use a different event to trigger them
  if( !transitionsSupported ) transitionEnd = 'noTransition';

  //should add a loding while the events are organized

  function SchedulePlan( element ) {
    this.element = element;
    this.timeline = this.element.find('.timeline');
    this.timelineItems = this.timeline.find('li');
    this.timelineItemsNumber = this.timelineItems.length;
    this.timelineStart = getScheduleTimestamp(this.timelineItems.eq(0).text());
    //need to store delta (in our case half hour) timestamp
    this.timelineUnitDuration = getScheduleTimestamp(this.timelineItems.eq(1).text()) - getScheduleTimestamp(this.timelineItems.eq(0).text());

    this.eventsWrapper = this.element.find('.events');
    this.eventsGroup = this.eventsWrapper.find('.events-group');
    this.singleEvents = this.eventsGroup.find('.single-event');
    this.eventSlotHeight = this.eventsGroup.eq(0).children('.top-info').outerHeight();

    this.modal = this.element.find('.event-modal');
    this.modalHeader = this.modal.find('.header');
    this.modalHeaderBg = this.modal.find('.header-bg');
    this.modalBody = this.modal.find('.body');
    this.modalBodyBg = this.modal.find('.body-bg');
    this.modalMaxWidth = 800;
    this.modalMaxHeight = 480;

    this.animating = false;

    this.initSchedule();
  }

  SchedulePlan.prototype.initSchedule = function() {
    this.scheduleReset();
    this.initEvents();
  };

  SchedulePlan.prototype.scheduleReset = function() {
    var mq = this.mq();
    if( mq == 'desktop' && !this.element.hasClass('js-full') ) {
      //in this case you are on a desktop version (first load or resize from mobile)
      this.eventSlotHeight = this.eventsGroup.eq(0).children('.top-info').outerHeight();
      this.element.addClass('js-full');
      this.placeEvents();
      this.element.hasClass('modal-is-open') && this.checkEventModal();
    } else if(  mq == 'mobile' && this.element.hasClass('js-full') ) {
      //in this case you are on a mobile version (first load or resize from desktop)
      this.element.removeClass('js-full loading');
      this.eventsGroup.children('ul').add(this.singleEvents).removeAttr('style');
      this.eventsWrapper.children('.grid-line').remove();
      this.element.hasClass('modal-is-open') && this.checkEventModal();
    } else if( mq == 'desktop' && this.element.hasClass('modal-is-open')){
      //on a mobile version with modal open - need to resize/move modal window
      this.checkEventModal('desktop');
      this.element.removeClass('loading');
    } else {
      this.element.removeClass('loading');
    }
  };

  SchedulePlan.prototype.initEvents = function() {
    var self = this;

    this.singleEvents.each(function(){
      //create the .event-date element for each event
      var durationLabel = '<span class="event-date">'+$(this).data('start')+' - '+$(this).data('end')+'</span>';
      $(this).children('a').prepend($(durationLabel));

      //detect click on the event and open the modal
      $(this).on('click', 'a', function(event){
        event.preventDefault();
        if( !self.animating ) self.openModal($(this));
      });
    });

    //close modal window
    this.modal.on('click', '.close', function(event){
      event.preventDefault();
      if( !self.animating ) self.closeModal(self.eventsGroup.find('.selected-event'));
    });
    this.element.on('click', '.cover-layer', function(event){
      if( !self.animating && self.element.hasClass('modal-is-open') ) self.closeModal(self.eventsGroup.find('.selected-event'));
    });
  };

  SchedulePlan.prototype.placeEvents = function() {
    var self = this;
    this.singleEvents.each(function(){
      //place each event in the grid -> need to set top position and height
      var start = getScheduleTimestamp($(this).attr('data-start')),
        duration = getScheduleTimestamp($(this).attr('data-end')) - start;

      var eventTop = self.eventSlotHeight*(start - self.timelineStart)/self.timelineUnitDuration,
        eventHeight = self.eventSlotHeight*duration/self.timelineUnitDuration;

      $(this).css({
        top: (eventTop -1) +'px',
        height: (eventHeight+1)+'px'
      });
    });

    this.element.removeClass('loading');
  };

  SchedulePlan.prototype.openModal = function(event) {
    var self = this;
    var mq = self.mq();
    this.animating = true;

    //update event name and time
    this.modalHeader.find('.event-name').text(event.find('.event-name').text());
    this.modalHeader.find('.event-date').text(event.find('.event-date').text());
    this.modal.attr('data-event', event.parent().attr('data-event'));

    //update event content
    this.modalBody.find('.event-info').load(event.parent().attr('data-content')+'.html .event-info > *', function(data){
      //once the event content has been loaded
      self.element.addClass('content-loaded');
    });

    this.element.addClass('modal-is-open');

    setTimeout(function(){
      //fixes a flash when an event is selected - desktop version only
      event.parent('li').addClass('selected-event');
    }, 10);

    if( mq == 'mobile' ) {
      self.modal.one(transitionEnd, function(){
        self.modal.off(transitionEnd);
        self.animating = false;
      });
    } else {
      var eventTop = event.offset().top - $(window).scrollTop(),
        eventLeft = event.offset().left,
        eventHeight = event.innerHeight(),
        eventWidth = event.innerWidth();

      var windowWidth = $(window).width(),
        windowHeight = $(window).height();

      var modalWidth = ( windowWidth*.8 > self.modalMaxWidth ) ? self.modalMaxWidth : windowWidth*.8,
        modalHeight = ( windowHeight*.8 > self.modalMaxHeight ) ? self.modalMaxHeight : windowHeight*.8;

      var modalTranslateX = parseInt((windowWidth - modalWidth)/2 - eventLeft),
        modalTranslateY = parseInt((windowHeight - modalHeight)/2 - eventTop);

      var HeaderBgScaleY = modalHeight/eventHeight,
        BodyBgScaleX = (modalWidth - eventWidth);

      //change modal height/width and translate it
      self.modal.css({
        top: eventTop+'px',
        left: eventLeft+'px',
        height: modalHeight+'px',
        width: modalWidth+'px',
      });
      transformElement(self.modal, 'translateY('+modalTranslateY+'px) translateX('+modalTranslateX+'px)');

      //set modalHeader width
      self.modalHeader.css({
        width: eventWidth+'px',
      });
      //set modalBody left margin
      self.modalBody.css({
        marginLeft: eventWidth+'px',
      });

      //change modalBodyBg height/width ans scale it
      self.modalBodyBg.css({
        height: eventHeight+'px',
        width: '1px',
      });
      transformElement(self.modalBodyBg, 'scaleY('+HeaderBgScaleY+') scaleX('+BodyBgScaleX+')');

      //change modal modalHeaderBg height/width and scale it
      self.modalHeaderBg.css({
        height: eventHeight+'px',
        width: eventWidth+'px',
      });
      transformElement(self.modalHeaderBg, 'scaleY('+HeaderBgScaleY+')');

      self.modalHeaderBg.one(transitionEnd, function(){
        //wait for the  end of the modalHeaderBg transformation and show the modal content
        self.modalHeaderBg.off(transitionEnd);
        self.animating = false;
        self.element.addClass('animation-completed');
      });
    }

    //if browser do not support transitions -> no need to wait for the end of it
    if( !transitionsSupported ) self.modal.add(self.modalHeaderBg).trigger(transitionEnd);
  };

  SchedulePlan.prototype.closeModal = function(event) {
    var self = this;
    var mq = self.mq();

    this.animating = true;

    if( mq == 'mobile' ) {
      this.element.removeClass('modal-is-open');
      this.modal.one(transitionEnd, function(){
        self.modal.off(transitionEnd);
        self.animating = false;
        self.element.removeClass('content-loaded');
        event.removeClass('selected-event');
      });
    } else {
      var eventTop = event.offset().top - $(window).scrollTop(),
        eventLeft = event.offset().left,
        eventHeight = event.innerHeight(),
        eventWidth = event.innerWidth();

      var modalTop = Number(self.modal.css('top').replace('px', '')),
        modalLeft = Number(self.modal.css('left').replace('px', ''));

      var modalTranslateX = eventLeft - modalLeft,
        modalTranslateY = eventTop - modalTop;

      self.element.removeClass('animation-completed modal-is-open');

      //change modal width/height and translate it
      this.modal.css({
        width: eventWidth+'px',
        height: eventHeight+'px'
      });
      transformElement(self.modal, 'translateX('+modalTranslateX+'px) translateY('+modalTranslateY+'px)');

      //scale down modalBodyBg element
      transformElement(self.modalBodyBg, 'scaleX(0) scaleY(1)');
      //scale down modalHeaderBg element
      transformElement(self.modalHeaderBg, 'scaleY(1)');

      this.modalHeaderBg.one(transitionEnd, function(){
        //wait for the  end of the modalHeaderBg transformation and reset modal style
        self.modalHeaderBg.off(transitionEnd);
        self.modal.addClass('no-transition');
        setTimeout(function(){
          self.modal.add(self.modalHeader).add(self.modalBody).add(self.modalHeaderBg).add(self.modalBodyBg).attr('style', '');
        }, 10);
        setTimeout(function(){
          self.modal.removeClass('no-transition');
        }, 20);

        self.animating = false;
        self.element.removeClass('content-loaded');
        event.removeClass('selected-event');
      });
    }

    //browser do not support transitions -> no need to wait for the end of it
    if( !transitionsSupported ) self.modal.add(self.modalHeaderBg).trigger(transitionEnd);
  }

  SchedulePlan.prototype.mq = function(){
    //get MQ value ('desktop' or 'mobile')
    var self = this;
    return window.getComputedStyle(this.element.get(0), '::before').getPropertyValue('content').replace(/["']/g, '');
  };

  SchedulePlan.prototype.checkEventModal = function(device) {
    this.animating = true;
    var self = this;
    var mq = this.mq();

    if( mq == 'mobile' ) {
      //reset modal style on mobile
      self.modal.add(self.modalHeader).add(self.modalHeaderBg).add(self.modalBody).add(self.modalBodyBg).attr('style', '');
      self.modal.removeClass('no-transition');
      self.animating = false;
    } else if( mq == 'desktop' && self.element.hasClass('modal-is-open') ) {
      self.modal.addClass('no-transition');
      self.element.addClass('animation-completed');
      var event = self.eventsGroup.find('.selected-event');

      var eventTop = event.offset().top - $(window).scrollTop(),
        eventLeft = event.offset().left,
        eventHeight = event.innerHeight(),
        eventWidth = event.innerWidth();

      var windowWidth = $(window).width(),
        windowHeight = $(window).height();

      var modalWidth = ( windowWidth*.8 > self.modalMaxWidth ) ? self.modalMaxWidth : windowWidth*.8,
        modalHeight = ( windowHeight*.8 > self.modalMaxHeight ) ? self.modalMaxHeight : windowHeight*.8;

      var HeaderBgScaleY = modalHeight/eventHeight,
        BodyBgScaleX = (modalWidth - eventWidth);

      setTimeout(function(){
        self.modal.css({
          width: modalWidth+'px',
          height: modalHeight+'px',
          top: (windowHeight/2 - modalHeight/2)+'px',
          left: (windowWidth/2 - modalWidth/2)+'px',
        });
        transformElement(self.modal, 'translateY(0) translateX(0)');
        //change modal modalBodyBg height/width
        self.modalBodyBg.css({
          height: modalHeight+'px',
          width: '1px',
        });
        transformElement(self.modalBodyBg, 'scaleX('+BodyBgScaleX+')');
        //set modalHeader width
        self.modalHeader.css({
          width: eventWidth+'px',
        });
        //set modalBody left margin
        self.modalBody.css({
          marginLeft: eventWidth+'px',
        });
        //change modal modalHeaderBg height/width and scale it
        self.modalHeaderBg.css({
          height: eventHeight+'px',
          width: eventWidth+'px',
        });
        transformElement(self.modalHeaderBg, 'scaleY('+HeaderBgScaleY+')');
      }, 10);

      setTimeout(function(){
        self.modal.removeClass('no-transition');
        self.animating = false;
      }, 20);
    }
  };

  var schedules = $('.cd-schedule');
  var objSchedulesPlan = [],
    windowResize = false;

  if( schedules.length > 0 ) {
    schedules.each(function(){
      //create SchedulePlan objects
      objSchedulesPlan.push(new SchedulePlan($(this)));
    });
  }

  $(window).on('resize', function(){
    if( !windowResize ) {
      windowResize = true;
      (!window.requestAnimationFrame) ? setTimeout(checkResize) : window.requestAnimationFrame(checkResize);
    }
  });

  $(window).keyup(function(event) {
    if (event.keyCode == 27) {
      objSchedulesPlan.forEach(function(element){
        element.closeModal(element.eventsGroup.find('.selected-event'));
      });
    }
  });

  function checkResize(){
    objSchedulesPlan.forEach(function(element){
      element.scheduleReset();
    });
    windowResize = false;
  }

  function getScheduleTimestamp(time) {
    //accepts hh:mm format - convert hh:mm to timestamp
    time = time.replace(/ /g,'');
    var timeArray = time.split(':');
    var timeStamp = parseInt(timeArray[0])*60 + parseInt(timeArray[1]);
    return timeStamp;
  }

  function transformElement(element, value) {
    element.css({
        '-moz-transform': value,
        '-webkit-transform': value,
      '-ms-transform': value,
      '-o-transform': value,
      'transform': value
    });
  }
 });
</script>


<!--- Calender end --->
<!--- Kode af Ann Cathrine slut --->

<!--- Kode af Pernille --->
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title" id="barogcafe">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">
        <center>Bar & Café</center></a>
      </h4>
    </div>
    <div id="collapse2" class="panel-collapse collapse">
      <div class="panel-body">
        <p>Vores barkort er fyldt med lækre drikke og vi har noget for enhver smag! Er du til en helt basal sort kaffe, en kold Royal øl eller en lækker drink? Vi har det hele – se vores store udvalg her på siden!</p>
        <img src="images/barkort.jpg" alt="Barkort" class="img displayed">
    </div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title" id="voreshistorie">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">
        <center>Vores Historie</center></a>
      </h4>
    </div>

    <div id="collapse3" class="panel-collapse collapse">
      <div class="panel-body">
        <p>Hos Café Under Masken er vi en mangfoldig café og bar med plads til hygge og sjov. Vi har eksisteret i 23 år, og er startet af kunstneren Hans Krull, der stadig ejer Café Under Masken den dag idag.
          I 1994 fik han tilbudt lokalerne af Hotel Royal, som en betaling for hans arbejde, da han malede og udsmykkede Casino Royal. </p>
          <p>Hele Café Under Masken er dekoreret fra gulv til loft af kunstneren selv, med en unik stil, stjernehimmel og et stort akvarie der dækker hele den bagerste væg.
            I den lille gang ved siden af toiletterne, er vores vægge fyldt med billeder af de mange forskellige kendte ansigter, der har besøgt Café Under Masken i årenes løb.
            <p>Hos os må du ryge indenfor, også om dagen. Caféen åbner fra kl 12.00 i alle hverdage, hvor du bla. kan komme og nyde varme drikke eller en kold øl.
              Vi har gratis wi-fi og en masse nye tilbud hver eneste dag. Kom indenfor hos Café Under Masken og oplev den historiske og kunstneriske stemning vi gemmer på.</p>
        <img src="images/masken1.jpg" alt="Café Under Masken" class="img displayed">
      </div>
    </div>
  </div>
<!--- Kode af Pernille slut --->

<!--- Kode af Martin --->
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title" id="kontaktos">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse4">
        <center>Kontakt Os</center></a>
      </h4>
    </div>
    <div id="collapse4" class="panel-collapse collapse">
      <div class="panel-body">
        <p>Har du nogle spørgsmål eller noget du gerne vil vide mere om, er du meget velkommen til at sende os en besked via kontaktformularen nedenfor! </p>
        <div class="container">
          <form id="contact" action="" method="post">
              <h2>Kontakt os</h2>
              <h4>Kontakt os og vi svarer på rekordtid!</h4>
              <fieldset>
                <input placeholder="Dit navn" type="text" tabindex="1" required autofocus>
              </fieldset>
              <fieldset>
                <input placeholder="Din email" type="email" tabindex="2" required>
              </fieldset>
              <fieldset>
                <input placeholder="Dit telefonnummer" type="tel" tabindex="3" required>
              </fieldset>
              <fieldset>
                <textarea placeholder="Skriv din besked her...." tabindex="5" required></textarea>
              </fieldset>
              <fieldset>
                <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Send besked</button>
              </fieldset>
            </form>
          </div>
        </div>
    </div>
</div>
</div>


<!--- Main end --->
<!--- Kode af Martin slit--->

<!--- Footer --->
<?php include 'includes/footer.php';?>
<!--- Footer end --->

</body>
</html>
