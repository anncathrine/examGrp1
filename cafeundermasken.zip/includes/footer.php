<footer>
<div class="col-lg-12 col-md-12 col-sm-12- col-xs-12">
  <div class="panel-footer">
    <img src="images/tider.png" alt="åbningstider" class="åbningstider">
        <img src="images/google.png" alt="google maps" class="google">
          <div class="icons">
            <center>
                <a href="https://www.facebook.com/Caf%C3%A9-Under-Masken-112421315453548/" target="_blank"> <img title="Facebook" alt="Facebook" src="images/facebook.png" width="30px" /></a>
                <a href="https://www.instagram.com/undermasken/?hl=da" target="_blank"> <img title="Instagram" alt="Instagram" src="images/instagram.png"  /></a>
            </div>
          </center>
          <center>
      <p id="copyright">Copyright &copy; 2017 - Café Under Masken</p>
  </center>
  </div>
</div>
</footer> 
