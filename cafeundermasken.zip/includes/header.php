<header>
<div class="topnav" id="myTopnav">
 <a href="#tiltop">Til top</a>
 <a href="#events">Events</a>
 <a href="#barogcafe">Bar & Café</a>
 <a href="#voreshistorie">Vores historie</a>
 <a href="#kontaktos">Kontakt os</a>
 <a href="javascript:void(0);" class="icon" onclick="myFunction()">&#9776;</a>
</div>

<script>/* Toggle between adding and removing the "responsive" class to topnav when the user clicks on the icon */
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
</header>
